# 🎯 BLKOUT Dual-Platform Extension Guide

## Overview

The **BLKOUT Liberation Moderator Tools** extension intelligently submits content to **TWO** platforms:

1. **📰 News Platform** (`news-blkout.vercel.app`) - For news articles and stories
2. **📅 Events Calendar** (`events-blkout.vercel.app`) - For community events

The extension automatically routes submissions to the correct platform based on the content type you select.

---

## How It Works

### Content Type Routing

When you click "Submit to Moderation Queue", the extension:

1. **Checks the content type** you selected (Event / News / Story)
2. **Routes to the appropriate API**:
   - `event` → Events Calendar API
   - `news` or `story` → News Platform API
3. **Formats data** according to each platform's requirements
4. **Submits for moderation** with appropriate metadata

---

## Content Types Explained

### 📅 Event
**Routes to**: `events-blkout.vercel.app/api/submit-event`

**Use for**:
- Community gatherings
- Workshops and meetups
- Conferences and talks
- Protests and marches
- Celebrations and festivals
- Any time-specific happening

**What gets submitted**:
```javascript
{
  title: "Event name",
  date: "2025-10-20",
  time: "19:00",
  location: "Venue or online",
  description: "Event details",
  url: "Source URL",
  tags: ["community", "workshop"],
  organizer: "Community Submission",
  source: "chrome-extension"
}
```

**Appears in**: Events calendar moderation queue → Approved events show on public calendar

---

### 📰 News
**Routes to**: `news-blkout.vercel.app/api/submit-article`

**Use for**:
- Breaking news articles
- Press releases
- Reports and investigations
- Political updates
- Crisis responses
- Official statements

**What gets submitted**:
```javascript
{
  title: "Article headline",
  url: "Article URL",
  excerpt: "Article summary",
  category: "politics/liberation/community/etc",
  content: "Extracted text",
  type: "news",
  submittedBy: "moderator-xxx"
}
```

**Appears in**: News platform moderation queue → Approved articles show in news feed

---

### 📖 Story
**Routes to**: `news-blkout.vercel.app/api/submit-article`

**Use for**:
- Personal narratives
- Community testimonies
- Lived experiences
- Journey stories
- Memoir pieces
- First-person accounts

**What gets submitted**:
```javascript
{
  title: "Story title",
  url: "Story URL",
  excerpt: "Story summary",
  category: "community/culture",
  content: "Extracted text",
  type: "story",
  submittedBy: "moderator-xxx"
}
```

**Appears in**: News platform moderation queue → Approved stories show in stories section

---

## Step-by-Step Usage

### Submitting an Event

1. **Navigate to event page** (Eventbrite, Facebook Event, etc.)
2. **Click extension icon** - popup opens
3. **Auto-detection runs**:
   - Extension analyzes content
   - Auto-suggests "Event" type if it detects:
     - Date/time patterns
     - Location information
     - Event-related keywords
4. **Review extracted data**:
   - ✅ Event title
   - ✅ Date and time (auto-extracted if available)
   - ✅ Location (auto-extracted if available)
   - ✅ Description
5. **Fill in event-specific fields**:
   - Event Date (required)
   - Event Location (optional but recommended)
   - Event Capacity (optional)
6. **Click "Submit to Moderation Queue"**
7. **Success**: "Event submitted to events calendar moderation queue!"

**Result**: Event appears in events calendar admin panel for approval

---

### Submitting News Article

1. **Navigate to news article** (BBC, Guardian, independent sites)
2. **Click extension icon** - popup opens
3. **Auto-detection runs**:
   - Extension analyzes content
   - Auto-suggests "News" type if it detects:
     - News-related keywords
     - Recent publication dates
     - Article structure
4. **Review extracted data**:
   - ✅ Article headline
   - ✅ Summary/excerpt
   - ✅ Source URL
   - ✅ Preview image
5. **Select category** via tags:
   - liberation, politics, community, culture, etc.
6. **Click "Submit to Moderation Queue"**
7. **Success**: "Content submitted to news platform moderation queue!"

**Result**: Article appears in news platform admin panel for approval

---

### Submitting Story

1. **Navigate to personal story** (blog, Medium, personal site)
2. **Click extension icon** - popup opens
3. **Auto-detection runs**:
   - Extension analyzes content
   - Auto-suggests "Story" type if it detects:
     - Story-related keywords
     - First-person narrative
     - Personal testimony
4. **Review extracted data**:
   - ✅ Story title
   - ✅ Summary
   - ✅ Source URL
5. **Add relevant tags** (optional)
6. **Click "Submit to Moderation Queue"**
7. **Success**: "Content submitted to news platform moderation queue!"

**Result**: Story appears in news platform admin panel for approval

---

## Smart Auto-Detection

The extension uses intelligent keyword analysis to suggest the best content type:

### Event Detection
- **Keywords**: event, workshop, meetup, conference, gathering, march, protest, rally
- **Data**: Date/time patterns, location mentions
- **Score**: +2 points if date or location extracted

### News Detection
- **Keywords**: breaking, news, report, announces, statement, response, crisis

### Story Detection
- **Keywords**: story, journey, experience, narrative, testimony, memoir

**How it works**:
1. Extension scans page title and content
2. Counts keyword matches for each type
3. Selects type with highest score
4. You can override by clicking a different type button

---

## API Endpoints

### Events Calendar API
```
POST https://events-blkout.vercel.app/api/submit-event

Required fields:
- title
- date

Optional fields:
- time
- location
- description
- url
- tags
- organizer
```

### News Platform API
```
POST https://news-blkout.vercel.app/api/submit-article

Required fields:
- title
- url

Optional fields:
- excerpt
- category
- content
- type (news/story)
```

---

## Backend Databases

### Events Calendar → Supabase `events` table
**Columns**:
- id, title, date, start_time, end_time
- location, description, url
- tags[], organizer, source
- status (pending/approved/archived)
- created_at, updated_at

**Moderation**: Events start as `status: pending`, admin approves/rejects

---

### News Platform → Supabase `moderation_queue` table
**Columns**:
- id, title, url, excerpt
- category, content, type
- status (pending/approved/rejected)
- submitted_by, submitted_at
- votes, priority

**Moderation**: Articles start as `status: pending`, admin approves/rejects

---

## Verification Checklist

### For Events:
- [ ] Event appears in events calendar admin panel
- [ ] Date and time are correct
- [ ] Location is accurate
- [ ] Description is complete
- [ ] Status is "pending"

### For News/Stories:
- [ ] Article appears in news platform admin panel
- [ ] Title and URL are correct
- [ ] Category is appropriate
- [ ] Excerpt is readable
- [ ] Status is "pending"

---

## Common Scenarios

### Scenario 1: Black Trans Joy Workshop
**Type**: Event
**Route**: Events Calendar
**Fields**:
- Title: "Black Trans Joy Workshop"
- Date: "2025-11-15"
- Time: "18:00"
- Location: "Community Center, London"
- Description: "Join us for healing and community building"

---

### Scenario 2: Breaking News on Policy Change
**Type**: News
**Route**: News Platform
**Fields**:
- Title: "New Housing Policy Announced"
- URL: "https://bbc.com/news/..."
- Category: "politics"
- Excerpt: "Government announces changes..."

---

### Scenario 3: Personal Coming Out Story
**Type**: Story
**Route**: News Platform
**Fields**:
- Title: "My Journey to Self-Acceptance"
- URL: "https://medium.com/@author/..."
- Category: "community"
- Excerpt: "This is my story of..."

---

## Success Messages

The extension provides clear feedback about where content was submitted:

**Events**:
> ✅ Event submitted to events calendar moderation queue!

**News**:
> ✅ Content submitted to news platform moderation queue!

**Stories**:
> ✅ Content submitted to news platform moderation queue!

---

## Troubleshooting

### Event not appearing in calendar?
- ✅ Check events calendar admin panel: https://events-blkout.vercel.app/admin
- ✅ Verify date is in YYYY-MM-DD format
- ✅ Check Supabase `events` table for `status: pending` entries

### Article not appearing in news?
- ✅ Check news platform admin panel
- ✅ Verify URL is valid
- ✅ Check Supabase `moderation_queue` table for `status: pending` entries

### Wrong platform selected?
- ✅ Click correct content type button before submitting
- ✅ Extension icon shows which type is selected (highlighted button)

---

## Admin Workflows

### Approving Events (Events Calendar)
1. Go to events calendar admin panel
2. View pending events (`status: pending`)
3. Review event details
4. Click "Approve" → Event publishes to public calendar
5. Click "Reject" → Event archived

### Approving News/Stories (News Platform)
1. Go to news platform admin panel
2. View moderation queue (`status: pending`)
3. Review article/story details
4. Click "Approve" → Content publishes to news feed
5. Click "Reject" → Content marked rejected

---

## Version History

**v2.2.0** (2025-10-13):
- ✅ Added dual-platform support
- ✅ Intelligent API routing based on content type
- ✅ Event-specific submission to events calendar
- ✅ News/story submission to news platform
- ✅ Fixed null reference and duplicate context menu errors

**v2.1.0** (Previous):
- News platform support only

---

## Technical Details

**Host Permissions**:
```json
[
  "https://news-blkout.vercel.app/*",
  "https://events-blkout.vercel.app/*",
  "https://blkout.vercel.app/*"
]
```

**API CORS**: Both platforms have CORS enabled (`Access-Control-Allow-Origin: *`)

**Authentication**: Anonymous submissions allowed, tracked by moderator UUID

---

**🎉 The extension now fully supports both BLKOUT platforms!**

Use the extension to curate content for both the news platform and events calendar, ensuring the BLKOUT community stays informed and connected.
