// BLKOUT Newsroom Extension - Article Submission
const NEWSROOM_URL = 'https://news-blkout.vercel.app';

// Inject this into popup.js submitToBlkout function to add newsroom support
async function submitToNewsroom(articleData) {
  try {
    console.log('📰 Submitting to BLKOUT Newsroom...', articleData);

    const newsroomData = {
      title: articleData.title,
      url: articleData.sourceUrl || window.location.href,
      excerpt: articleData.excerpt || articleData.description || '',
      category: articleData.category || 'community',
      submittedBy: 'chrome-extension'
    };

    const response = await fetch(`${NEWSROOM_URL}/api/submit-article`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(newsroomData)
    });

    const result = await response.json();

    if (result.success) {
      console.log('✅ Successfully submitted to newsroom:', result.data);
      return { success: true, data: result.data };
    } else {
      console.error('❌ Newsroom submission failed:', result.error);
      return { success: false, error: result.error };
    }
  } catch (error) {
    console.error('❌ Newsroom API error:', error);
    return { success: false, error: error.message };
  }
}

// Enhanced submission function that submits to both platforms
async function submitToBothPlatforms(submitData, type) {
  const results = {
    platform: { success: false },
    newsroom: { success: false }
  };

  // Submit to main platform (events or articles)
  if (type === 'event') {
    // Events go to main platform only
    results.platform = await window.submitToBlkout(submitData, 'event');
  } else {
    // Articles go to BOTH platforms
    results.platform = await window.submitToBlkout(submitData, 'article');
    results.newsroom = await submitToNewsroom(submitData);
  }

  // Return combined result
  if (type === 'event') {
    return results.platform;
  } else {
    // For articles, success if either platform worked
    const anySuccess = results.platform.success || results.newsroom.success;
    const errors = [];

    if (!results.platform.success) errors.push(`Platform: ${results.platform.error}`);
    if (!results.newsroom.success) errors.push(`Newsroom: ${results.newsroom.error}`);

    return {
      success: anySuccess,
      data: {
        platform: results.platform.data,
        newsroom: results.newsroom.data
      },
      error: errors.length > 0 ? errors.join('; ') : null,
      partial: anySuccess && errors.length > 0
    };
  }
}

// Export for use in popup.js
if (typeof window !== 'undefined') {
  window.submitToNewsroom = submitToNewsroom;
  window.submitToBothPlatforms = submitToBothPlatforms;
}
