# 🎯 BLKOUT Liberation Moderator Tools v2.2.0

**Official Chrome Extension for BLKOUT Content Moderation**

A powerful content curation tool that enables volunteer moderators to quickly scrape and submit content to both BLKOUT platforms:
- 📰 **News Platform** - Articles, reports, and stories
- 📅 **Events Calendar** - Community events and gatherings

---

## ✨ Features

### Dual-Platform Support
- **Intelligent Routing**: Automatically submits to the correct platform based on content type
- **News & Stories**: Routes to news-blkout.vercel.app
- **Events**: Routes to events-blkout.vercel.app

### Smart Content Extraction
- **Auto-detection**: Analyzes page content and suggests the best content type
- **Title & Summary**: Extracts headlines and descriptions automatically
- **Images**: Captures featured images and OG images
- **Event Data**: Auto-extracts dates, times, locations, and capacity
- **URLs & Metadata**: Preserves source information

### Content Types
1. **📅 Event** - Community gatherings, workshops, protests, celebrations
2. **📰 News** - Breaking news, reports, political updates, press releases
3. **📖 Story** - Personal narratives, testimonies, lived experiences

### Moderation Tools
- **Submit to Queue**: Send content to platform-specific moderation queues
- **Save Draft**: Save content locally for later review
- **Mark Rejected**: Flag unsuitable content
- **Edit Before Submit**: Override extracted data with manual edits
- **Category Tagging**: Add relevant tags (liberation, politics, community, etc.)

### Stats Tracking
- Submitted today count
- Total submissions
- Approval rate
- Queue size

### Offline Support
- **Auto-save**: Saves submissions locally if API is unavailable
- **Sync Later**: Automatically syncs offline submissions when connection restored

---

## 📋 Installation

### Method 1: Load Unpacked (Recommended for Development)

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer Mode** (toggle in top right)
3. Click **"Load unpacked"**
4. Select this directory: `/home/robbe/ACTIVE_PROJECTS/BLKOUT_LIBERATION_PLATFORM/fixed-extension`
5. Extension should appear with version 2.2.0

### Method 2: From Archive

1. Extract the extension archive
2. Follow steps above to load unpacked

---

## 🚀 Quick Start

### Submitting an Event

1. **Navigate** to any event page (Eventbrite, Facebook Events, etc.)
2. **Click** the BLKOUT extension icon in your toolbar
3. **Review** auto-extracted content:
   - Event title
   - Date and time (if detected)
   - Location (if detected)
   - Description
4. **Fill in** event-specific fields:
   - Event Date (required)
   - Event Location (recommended)
   - Event Capacity (optional)
5. **Select** "Event" content type (may be auto-selected)
6. **Click** "Submit to Moderation Queue"
7. ✅ **Success**: Event submitted to events calendar moderation queue

**Result**: Event appears in events calendar admin panel for approval

---

### Submitting News Article

1. **Navigate** to any news article
2. **Click** the BLKOUT extension icon
3. **Review** auto-extracted content:
   - Article headline
   - Summary/excerpt
   - Source URL
   - Featured image
4. **Add tags** for categorization (optional):
   - liberation, politics, community, culture, etc.
5. **Select** "News" content type (may be auto-selected)
6. **Click** "Submit to Moderation Queue"
7. ✅ **Success**: Article submitted to news platform moderation queue

**Result**: Article appears in news platform admin panel for approval

---

### Submitting Story

1. **Navigate** to personal story or blog post
2. **Click** the BLKOUT extension icon
3. **Review** auto-extracted content
4. **Select** "Story" content type (may be auto-selected)
5. **Click** "Submit to Moderation Queue"
6. ✅ **Success**: Story submitted to news platform moderation queue

**Result**: Story appears in news platform admin panel for approval

---

## 🔧 How It Works

### Content Type Detection

The extension uses intelligent keyword analysis:

**Event Detection**:
- Keywords: event, workshop, meetup, conference, gathering, march, protest, rally
- Data: Date/time patterns, location mentions
- Score: +2 points if date or location extracted

**News Detection**:
- Keywords: breaking, news, report, announces, statement, response, crisis

**Story Detection**:
- Keywords: story, journey, experience, narrative, testimony, memoir

### API Routing

**For Events** (type="event"):
```
POST https://events-blkout.vercel.app/api/submit-event
→ Supabase events table
→ Events calendar moderation queue
```

**For News/Stories** (type="news"/"story"):
```
POST https://news-blkout.vercel.app/api/submit-article
→ Supabase moderation_queue table
→ News platform moderation queue
```

---

## 📚 Documentation

- **[Installation Guide](INSTALLATION_GUIDE.md)** - Detailed installation and troubleshooting
- **[API Connection Guide](API_CONNECTION_GUIDE.md)** - Backend API integration details
- **[Dual-Platform Guide](DUAL_PLATFORM_GUIDE.md)** - Complete guide to news and events submission
- **[Fixes Applied](FIXES_APPLIED.md)** - Recent bug fixes and improvements

---

## 🐛 Known Issues & Fixes (v2.2.0)

All known issues have been resolved:

✅ **Fixed**: Null reference error in content type selection
✅ **Fixed**: Duplicate context menu creation
✅ **Added**: Dual-platform support
✅ **Added**: Intelligent API routing

---

## 🔐 Permissions

The extension requires these permissions:

- **activeTab**: Access current tab to extract content
- **storage**: Save stats, drafts, and offline submissions locally
- **notifications**: Display success/error messages
- **scripting**: Execute content extraction scripts
- **contextMenus**: Add "Add to Moderation Queue" right-click option

### Host Permissions

- `https://news-blkout.vercel.app/*` - News platform API
- `https://events-blkout.vercel.app/*` - Events calendar API
- `https://blkout.vercel.app/*` - Main BLKOUT platform

---

## 🧪 Testing

### Test on Real Pages

**Events**:
- https://www.eventbrite.com/
- https://www.facebook.com/events/
- https://www.meetup.com/

**News**:
- https://www.bbc.com/news
- https://www.theguardian.com/uk
- https://www.vice.com

**Stories**:
- https://medium.com/
- Personal blogs
- Community storytelling sites

### Verify Submissions

**Events Calendar Admin**:
- Go to https://events-blkout.vercel.app/admin
- Check for pending events (`status: pending`)
- Verify all fields populated correctly

**News Platform Admin**:
- Go to news-blkout admin panel
- Check moderation queue (`status: pending`)
- Verify articles/stories appear correctly

---

## 📊 Version History

**v2.2.0** (2025-10-13):
- ✅ Added dual-platform support (news and events)
- ✅ Intelligent API routing based on content type
- ✅ Event-specific submission to events calendar
- ✅ News/story submission to news platform
- ✅ Fixed null reference error on line 254
- ✅ Fixed duplicate context menu error
- ✅ Updated extension description and title

**v2.1.0** (Previous):
- News platform support only
- Basic content extraction

---

## 🆘 Troubleshooting

### Extension won't load
- ✅ Enable Developer Mode in `chrome://extensions/`
- ✅ Check that all files exist in the extension directory
- ✅ Reload the extension

### Content not extracted
- ✅ Reload the extension
- ✅ Reload the webpage you're testing on
- ✅ Check console for permission errors

### Submission fails
- ✅ Check internet connection
- ✅ Verify API endpoints are accessible
- ✅ Check console for detailed error messages
- ✅ Content is saved locally if submission fails

### Wrong platform selected
- ✅ Click the correct content type button (Event/News/Story)
- ✅ The selected button will be highlighted
- ✅ You can override auto-detection

---

## 👥 For Volunteer Moderators

This extension is designed for BLKOUT community moderators to efficiently curate content for both platforms:

### Best Practices

1. **Verify Content**: Always review auto-extracted data before submitting
2. **Choose Correct Type**: Select Event/News/Story appropriately
3. **Add Context**: Use tags and manual edits to provide additional context
4. **Check Dates**: For events, ensure date and time are accurate
5. **Location Matters**: For events, add location even if not auto-detected

### Moderation Workflow

1. Browse the web for relevant content
2. Use extension to quickly extract and submit
3. Admin reviews submissions in respective platforms
4. Approved content appears on public-facing platforms
5. Track your stats and contribution

---

## 🔗 Related Projects

- **News Platform**: https://github.com/yourusername/news-blkout
- **Events Calendar**: https://github.com/yourusername/events-blkout
- **BLKOUT Main**: https://github.com/yourusername/blkout-platform

---

## 📝 License

Part of the BLKOUT Liberation Platform ecosystem.

---

## 🤝 Support

**Issues?** Check the documentation guides first:
- [Installation Guide](INSTALLATION_GUIDE.md)
- [API Connection Guide](API_CONNECTION_GUIDE.md)
- [Dual-Platform Guide](DUAL_PLATFORM_GUIDE.md)

**Still stuck?** Open an issue or contact the BLKOUT development team.

---

**🎉 Ready to curate content for the BLKOUT community!**

Use this extension to help build a comprehensive news and events platform that serves and uplifts Black queer communities.
