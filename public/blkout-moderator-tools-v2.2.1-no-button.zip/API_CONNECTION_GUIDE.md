# 🔌 API Connection Guide - Extension to Backend

## ✅ Good News: API is Working!

I tested the API and it's functioning correctly:
- **API URL:** `https://news-blkout.vercel.app/api/submit-article`
- **Status:** ✅ Working (test submission successful)
- **Response:** Returns proper JSON with success message

---

## 🔍 Current Extension Configuration

The extension is correctly configured to use:
```javascript
// In popup.js line 8:
this.apiEndpoint = 'https://news-blkout.vercel.app/api';

// Submits to:
${this.apiEndpoint}/submit-article
```

This is the RIGHT endpoint and it's working!

---

## 🧪 Testing the Extension Connection

### Step 1: Load the Extension
1. Open Chrome → `chrome://extensions/`
2. Enable Developer Mode
3. Load unpacked → Select `fixed-extension` folder
4. Extension should appear with no errors

### Step 2: Test on a Real Page
1. Go to any news article, for example:
   - https://www.bbc.com/news
   - https://www.theguardian.com/uk
   - https://www.vice.com

2. Click the **BLKOUT Moderator Tools** icon in toolbar

3. The popup should open and show:
   - ✅ Extracted title from the page
   - ✅ Extracted URL
   - ✅ Extracted summary/description
   - ✅ Content type buttons (Event/News/Story)

### Step 3: Test Submission
1. In the popup, review the extracted content
2. Make any edits if needed
3. Click **"Submit to Moderation Queue"** button
4. You should see:
   - ✅ Green success message: "Content submitted to moderation queue!"
   - ✅ Stats update (Submitted Today counter increases)

### Step 4: Verify in Backend
1. Go to https://news-blkout.vercel.app/admin (or wherever your moderation queue is)
2. Sign in as admin
3. Check the moderation queue
4. You should see the article you just submitted!

---

## 🐛 Troubleshooting Connection Issues

### Issue: "Failed to submit" error

**Possible Causes:**

#### 1. **CORS Error**
The API has CORS enabled (`Access-Control-Allow-Origin: *`), but check console:

**How to check:**
1. Right-click extension icon → Inspect popup
2. Open Console tab
3. Look for red CORS errors

**Fix:** Already configured correctly in API, should not be an issue.

#### 2. **Network Error / Extension Blocked**
Chrome may block extension network requests.

**How to check:**
1. Inspect popup → Console tab
2. Look for "net::ERR_" messages

**Fix:**
- Make sure you're connected to internet
- Try reloading the extension
- Check if your network/firewall blocks requests

#### 3. **API Request Format Wrong**

**How to check:**
Console will show 400 or 500 errors

**Current request format (from popup.js line 270):**
```javascript
fetch(`${this.apiEndpoint}/submit-article`, {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    title: contentData.edited.title,
    url: contentData.metadata.url,
    excerpt: contentData.edited.summary,
    category: this.getCategory(),
    content: contentData.original.content || '',
    submittedBy: `moderator-${moderatorId.slice(0, 8)}`,
    type: this.selectedType
  })
})
```

This matches the API requirements perfectly! ✅

#### 4. **Popup Opens But Content Not Extracted**

**Symptoms:**
- Popup shows "Loading page information..."
- Never updates with actual content

**Cause:** Content script permissions issue

**Fix:**
1. Check manifest.json has correct permissions (it does ✅)
2. Reload the extension
3. Reload the webpage you're testing on
4. Try again

---

## 🔍 Debugging Tools

### View Extension Console Logs

**Background Service Worker:**
```
1. chrome://extensions/
2. Find "BLKOUT Liberation Moderator Tools"
3. Click "service worker" link
4. Console shows all background.js logs
```

**Popup Console:**
```
1. Right-click extension icon
2. Select "Inspect popup"
3. Console shows all popup.js logs
```

### Check Network Requests

**In Popup Inspector:**
```
1. Inspect popup (right-click icon)
2. Go to "Network" tab
3. Click "Submit to Queue"
4. Watch for:
   - POST request to /api/submit-article
   - Status: 201 Created (success)
   - Response: {"success": true, ...}
```

---

## 📊 Expected Behavior

### Successful Submission Flow:

1. **User clicks extension icon**
   - Popup opens
   - `extractPageContent()` runs
   - Content extracted from current tab

2. **User clicks "Submit to Queue"**
   - `submitToQueue()` function runs
   - POST request sent to API
   - API validates data
   - Supabase inserts into `moderation_queue` table
   - API returns success response

3. **Extension shows success**
   - Green message: "Content submitted to moderation queue!"
   - Stats update (submittedToday +1)
   - Content saved to local storage

4. **Admin can view in backend**
   - Article appears in moderation queue
   - Status: "pending"
   - Can approve/reject from dashboard

---

## 🔐 API Authentication

Currently: **No authentication required** for submissions ✅

The API accepts anonymous submissions:
- `submittedBy: "moderator-{uuid}"`
- No API key needed
- No login required

This is by design for volunteer moderators!

---

## 📈 Testing Different Content Types

### Test Event Submission
1. Go to an event page (e.g., Eventbrite, Facebook event)
2. Open extension
3. Select "Event" content type
4. Extension auto-detects date/location
5. Submit → Should create event entry

### Test News Submission
1. Go to news article
2. Open extension
3. Select "News" content type
4. Submit → Should create news entry

### Test Story Submission
1. Go to personal blog or story
2. Open extension
3. Select "Story" content type
4. Submit → Should create story entry

---

## ✅ Verification Checklist

Run through this to confirm everything works:

**Extension Setup:**
- [ ] Extension loaded in Chrome
- [ ] No errors on extension card
- [ ] Extension enabled (blue toggle)
- [ ] Icon visible in toolbar

**Content Extraction:**
- [ ] Popup opens when icon clicked
- [ ] Page title extracted correctly
- [ ] URL displayed correctly
- [ ] Summary/description extracted
- [ ] Image preview shows (if available)

**API Connection:**
- [ ] Click "Submit to Queue"
- [ ] No console errors
- [ ] Success message appears
- [ ] Stats counter updates

**Backend Verification:**
- [ ] Go to news-blkout admin panel
- [ ] Check moderation queue
- [ ] Submitted article appears
- [ ] All fields populated correctly

---

## 🆘 Still Having Issues?

If the extension is NOT working after following this guide, please tell me:

1. **What specific error do you see?**
   - Screenshot or copy-paste exact error message
   - Check both popup console and background console

2. **What step fails?**
   - Extension loads but popup is blank?
   - Popup opens but content not extracted?
   - Submit button doesn't do anything?
   - Submit shows error message?

3. **Console logs:**
```
Right-click icon → Inspect popup → Console tab
Copy all red errors and share
```

4. **Network tab:**
```
Inspect popup → Network tab → Try submitting
Does the POST request appear?
What status code? (200, 400, 500, etc.)
```

---

## 🔧 Quick Manual Test

To verify the API works independently of the extension:

```bash
# Test from terminal:
curl -X POST https://news-blkout.vercel.app/api/submit-article \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Article from Extension",
    "url": "https://example.com/test",
    "excerpt": "This is a test submission",
    "category": "community",
    "type": "news"
  }'
```

Should return:
```json
{
  "success": true,
  "message": "Article submitted for moderation",
  "data": { ... }
}
```

If this works but extension doesn't, the issue is in the extension code, not the API!

---

**🎉 The API is confirmed working! The extension should connect successfully.**

Let me know the exact error you're seeing and I'll fix it immediately!
