# 🔧 Chrome Extension Installation & Troubleshooting Guide

## Quick Installation Steps

### 1. Open Chrome Extensions Page
- Open Chrome
- Go to: `chrome://extensions/`
- OR: Menu (⋮) → Extensions → Manage Extensions

### 2. Enable Developer Mode
- Toggle **"Developer mode"** ON (top right corner)
- You should see new buttons appear: "Load unpacked", "Pack extension", etc.

### 3. Load the Extension
- Click **"Load unpacked"** button
- Navigate to: `/home/robbe/ACTIVE_PROJECTS/BLKOUT_LIBERATION_PLATFORM/fixed-extension`
- Select the `fixed-extension` folder
- Click **"Select"** or **"Open"**

### 4. Verify Installation
- Extension should appear in your extensions list
- Name: "BLKOUT Liberation Moderator Tools"
- Version: 2.1.0
- You should see the extension icon in your toolbar

---

## ❌ Common Issues & Fixes

### Issue 1: "Manifest file is missing or unreadable"
**Cause:** Wrong folder selected

**Fix:**
1. Make sure you're selecting the `fixed-extension` folder itself
2. The folder should contain `manifest.json` directly inside it
3. Check path: `/home/robbe/ACTIVE_PROJECTS/BLKOUT_LIBERATION_PLATFORM/fixed-extension/manifest.json`

### Issue 2: "Icons not found" or missing icon
**Cause:** Icon files missing

**Fix:**
```bash
cd /home/robbe/ACTIVE_PROJECTS/BLKOUT_LIBERATION_PLATFORM/fixed-extension/icons
ls -la
```
Should see: `news-icon-16.png`, `news-icon-32.png`, `news-icon-48.png`, `news-icon-128.png`

If missing, I can generate placeholder icons for you.

### Issue 3: Extension loads but popup doesn't open
**Cause:** popup files missing or path wrong

**Fix:**
```bash
cd /home/robbe/ACTIVE_PROJECTS/BLKOUT_LIBERATION_PLATFORM/fixed-extension
ls -la popup/
```
Should see: `popup.html`, `popup.js`, `popup.css`

### Issue 4: "Unexpected token" or JavaScript errors
**Cause:** Syntax error in JS files

**Fix:**
1. Click extension in list
2. Click "Errors" button if you see it
3. Look at console errors
4. Share the error message with me

### Issue 5: Extension loads but doesn't extract content
**Cause:** Permissions or script injection issue

**Fix:**
1. Check that the extension has permissions
2. Try reloading the extension:
   - Go to `chrome://extensions/`
   - Find the extension
   - Click the refresh/reload icon (🔄)
3. Reload the web page you're testing on
4. Try clicking the extension icon again

### Issue 6: "Service worker registration failed"
**Cause:** background.js syntax error

**Fix:**
1. Check background service worker:
   - Go to `chrome://extensions/`
   - Find your extension
   - Click "service worker" link under "Inspect views"
   - Check console for errors

---

## 🧪 Testing the Extension

### Step 1: Visit a Test Page
Open any webpage with content, for example:
- https://www.bbc.com/news
- https://www.theguardian.com
- Any article or event page

### Step 2: Click Extension Icon
- Find the extension icon in your toolbar
- If not visible, click the puzzle piece icon (🧩) and pin the extension
- Click the BLKOUT Moderator Tools icon

### Step 3: Verify Popup Opens
You should see:
- Header: "MODERATOR TOOLS"
- Auto-extracted content section
- Page title and summary
- Content type buttons (Event, News, Story)
- Review & Edit fields
- Submit buttons

### Step 4: Test Content Extraction
- Check if the title was extracted
- Check if the URL shows correctly
- Check if summary was extracted
- Check if an image preview appears

### Step 5: Test Submission (Optional)
- Fill in any fields
- Click "Submit to Moderation Queue"
- Check for success/error message

---

## 📋 Diagnostic Checklist

Run through this checklist to identify issues:

**Extension Loading:**
- [ ] Developer mode is ON
- [ ] Extension appears in list at `chrome://extensions/`
- [ ] Extension is ENABLED (toggle is blue/on)
- [ ] No error messages on extension card

**Files Present:**
- [ ] `manifest.json` exists in root folder
- [ ] All icon files exist in `icons/` folder
- [ ] `popup/popup.html` exists
- [ ] `popup/popup.js` exists
- [ ] `popup/popup.css` exists
- [ ] `background.js` exists in root folder
- [ ] `content/content.js` exists

**Functionality:**
- [ ] Extension icon appears in toolbar
- [ ] Clicking icon opens popup window
- [ ] Popup displays content
- [ ] No JavaScript errors in console
- [ ] Content extraction works on test pages

---

## 🔍 Getting More Information

### View Extension Console
1. Go to `chrome://extensions/`
2. Find your extension
3. Click **"service worker"** under "Inspect views"
4. Console will show background.js logs and errors

### View Popup Console
1. Right-click the extension icon
2. Select **"Inspect popup"** (or just "Inspect")
3. Console will show popup.js logs and errors

### Check Manifest Errors
1. Go to `chrome://extensions/`
2. Look for **"Errors"** button on extension card
3. Click it to see manifest or permission issues

---

## 🆘 Still Not Working?

If none of the above helps, please provide:

1. **What error message do you see?**
   - Screenshot of `chrome://extensions/` page
   - Any error messages in red

2. **What happens when you click the icon?**
   - Nothing?
   - Popup opens but is blank?
   - Popup shows but has errors?

3. **Console errors?**
   - Open extension console (steps above)
   - Copy/paste any red error messages

4. **Which step fails?**
   - Can't load extension?
   - Extension loads but icon doesn't work?
   - Popup opens but doesn't extract content?
   - Submission doesn't work?

---

## 🔧 Quick Fixes to Try First

### Fix 1: Reload Extension
```
chrome://extensions/ → Find extension → Click reload icon (🔄)
```

### Fix 2: Re-install Extension
```
chrome://extensions/ → Find extension → Click "Remove"
Then: Load unpacked → Select folder again
```

### Fix 3: Check File Permissions
```bash
cd /home/robbe/ACTIVE_PROJECTS/BLKOUT_LIBERATION_PLATFORM/fixed-extension
ls -la
# All files should be readable (r--)
```

### Fix 4: Verify Manifest
```bash
cat /home/robbe/ACTIVE_PROJECTS/BLKOUT_LIBERATION_PLATFORM/fixed-extension/manifest.json
# Should be valid JSON (no syntax errors)
```

---

## 📦 Creating a Packaged Version (Optional)

If you want to create a .zip for easy sharing:

```bash
cd /home/robbe/ACTIVE_PROJECTS/BLKOUT_LIBERATION_PLATFORM
tar -czf blkout-moderator-extension.tar.gz fixed-extension/
# or
zip -r blkout-moderator-extension.zip fixed-extension/
```

---

**Need more help?** Let me know exactly what's happening and I'll help debug!
