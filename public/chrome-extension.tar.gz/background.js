// BLKOUT Extension Background Service Worker
// Minimal background script for Chrome Extension Manifest V3

// Listen for installation
chrome.runtime.onInstalled.addListener(() => {
  console.log('BLKOUT Extension installed successfully');
});

// Storage helpers
const storage = {
  async save(key, data) {
    return chrome.storage.local.set({ [key]: data });
  },

  async load(key) {
    const result = await chrome.storage.local.get([key]);
    return result[key];
  }
};
